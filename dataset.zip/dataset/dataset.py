import random
from shapely.geometry import Polygon,LineString, Point
import json, os
import inquirer
import sys
from tqdm import tqdm
sys.path.append("..")
from env import env as env_search, plotting as plotting_search

class Dataset:
    def __init__(self):
        self.MAP = [(50, 30)]
        self.unique_env = 100
        # 一套地图生成几个样本
        self.unique_sg = 10

    def generate_environment_RRT(self):
        for map in self.MAP:
            x_range, y_range = (0, map[0]+1), (0, map[1]+1)
            # 生成两种x长 y宽 2种障碍
            # with open('environment_50_30_2.json', 'r') as file:
            #     environments = json.load(file)
            environments = []
            cls = 0

            print('-------------- generate map ---------------')

            for i in tqdm(range(len(environments), self.unique_env)):
                # choose
                '''
                decision = False
                while not decision:
                    num_c = round(random.uniform(1, 4))
                    num_n = round(random.uniform(1, 4))

                    data = {'id': i}
                    data.update(self._generate_random_obstacles_and_points_RRT(x_range, y_range, num_c, num_n))
                    self.plot_RRT(data['start_goal'][9pic][9pic], data['start_goal'][9pic][1], data['range_x'], data['range_y'], data['cross_barriers'], data['avoid_barriers'], show=False)
                    action_planner = [
                        inquirer.List(
                            'approach',
                            message=f"Choose your approach on {i}",
                            choices=[('Bad', False), ('Good', True)],
                            default=False
                        )
                    ]
                    decision = inquirer.prompt(action_planner)['approach']
                '''
                # not choose
                num_c = 0
                num_n = round(random.uniform(1, 4))

                data = {'id': i}
                data.update(self._generate_random_obstacles_and_points_RRT(x_range, y_range, num_c, num_n))
                self.plot_RRT(data['start_goal'][0][0], data['start_goal'][0][1], data['range_x'], data['range_y'],
                              data['cross_barriers'], data['avoid_barriers'], show=False)
                # '''
                # ——————————————————————————————————————————————————————————————————————————————————————————————————————
                environments.append(data)
                
        with open(f'environment_50_30_{cls}.json', 'w') as f:
            json.dump(environments, f, indent=4)
        
        for i in tqdm(range(len(environments))):
            data = environments[i]
            for index in range(len(data['start_goal'])): 
                sg = data['start_goal'][index]
                if not os.path.exists(f"environment_{x_range[1]}_{y_range[1]}_maps_{cls}/map_{i}"):
                    os.makedirs(f"environment_{x_range[1]}_{y_range[1]}_maps_{cls}/map_{i}")
                self.plot_RRT(sg[0], sg[1], data['range_x'], data['range_y'], data['cross_barriers'], data['avoid_barriers'], f"map class {cls} id {i}-{index}", f"environment_{x_range[1]}_{y_range[1]}_maps_{cls}/map_{i}/{index}.png")
        
    def _generate_random_obstacles_and_points_RRT(self, x_range, y_range, num_cross, num_avoid):

        def generate_cross_obstacles(num_cross, x_range, y_range, existing_obstacles):
            num_cross_obstacles = []
            # 设置最小长度
            min_length = 20
            y_side = 5
            x_side = 5
            for _ in range(num_cross):
                while True:
                    # 随机生成矩形障碍
                    if random.random() < 0.5:  # 50% 概率生成横条
                        y_min = int(random.uniform(y_range[0] + y_side, y_range[1] - y_side))
                        y_max = y_min + 2  # 高度固定为 2
                        x_min = int(random.uniform(x_range[0] + x_side, x_range[1] - min_length))
                        x_max = int(random.uniform(x_min + min_length, x_range[1] - x_side))
                    else:  # 50% 概率生成纵条
                        x_min = int(random.uniform(x_range[0] + x_side, x_range[1] - x_side))
                        x_max = x_min + 2  # 宽度固定为 2
                        y_min = int(random.uniform(y_range[0] + y_side, y_range[1] - min_length))
                        y_max = int(random.uniform(y_min + min_length, y_range[1] - y_side))

                    # 矩形顶点顺时针顺序或逆时针顺序排列
                    rectangle = Polygon([(x_min, y_min), (x_max, y_min), (x_max, y_max), (x_min, y_max)])

                    # 障碍记录
                    num_cross_obstacles.append([(x_min, y_min), (x_max, y_min), (x_max, y_max), (x_min, y_max)])
                    existing_obstacles.append(rectangle)

                    break
            return num_cross_obstacles
        
        def generate_avoid_obstacles(num_avoid, x_range, y_range, existing_obstacles):
            vertical_obstacles = []
            # 设置最小长度
            min_length = 10
            y_side = 5
            x_side = 5
            for _ in range(num_avoid):
                while True:
                    # 随机生成矩形障碍
                    if random.random() < 0.5:  # 50% 概率生成横条
                        y_min = int(random.uniform(y_range[0] + y_side, y_range[1] - y_side))
                        y_max = y_min + 2  # 高度固定为 2
                        x_min = int(random.uniform(x_range[0] + x_side, x_range[1] - min_length))
                        x_max = int(random.uniform(x_min + min_length, x_range[1] - x_side))
                    else:  # 50% 概率生成纵条
                        x_min = int(random.uniform(x_range[0] + x_side, x_range[1] - x_side))
                        x_max = x_min + 2  # 宽度固定为 2
                        y_min = int(random.uniform(y_range[0] + y_side, y_range[1] - min_length))
                        y_max = int(random.uniform(y_min + min_length, y_range[1] - y_side))

                    # 矩形顶点顺时针顺序或逆时针顺序排列
                    rectangle = Polygon([(x_min, y_min), (x_max, y_min), (x_max, y_max), (x_min, y_max)])

                    # 障碍记录
                    vertical_obstacles.append([(x_min, y_min), (x_max, y_min), (x_max, y_max), (x_min, y_max)])
                    existing_obstacles.append(rectangle)
                    break
            return vertical_obstacles
        
        def generate_random_point(x_range, y_range, existing_obstacles):
            while True:
                x = int(random.uniform(x_range[0] + 2, x_range[1] - 2))
                y = int(random.uniform(y_range[0] + 2, y_range[1] - 2))
                point = Point(x, y)
                if not any(point.intersects(ob) for ob in existing_obstacles):
                    return [x, y]
        
        existing_obstacles = []

        cross_barriers = generate_cross_obstacles(num_cross, x_range, y_range, existing_obstacles)
        avoid_barriers = generate_avoid_obstacles(num_avoid, x_range, y_range, existing_obstacles)
        
        sg_list = []
        while len(sg_list) < self.unique_sg:
            start = generate_random_point(x_range, y_range, existing_obstacles)
            goal = generate_random_point(x_range, y_range, existing_obstacles)
            # 得有相交 别一下就过去了
            if any(LineString([start, goal]).intersects(ob) for ob in (existing_obstacles)):
                sg_list.append((start, goal))
        
        environment = {
            "range_x": x_range,
            "range_y": y_range,
            "cross_barriers": cross_barriers,
            "avoid_barriers": avoid_barriers,
            "start_goal": sg_list
        }
        # print(environment)

        return environment

    def add_query_RRT(self, filepath='add_query_RRT.json'):
        with open(filepath) as f:
            data = json.load(f)
        
        for environment in data:
            for sg in environment['start_goal']:
                start, goal = sg[0], sg[1]
                x_range = environment['range_x']
                y_range = environment['range_y']
                cross_barriers = environment['cross_barriers']
                avoid_obstacles = environment['avoid_obstacles']
                query = f"""design a path from [{start[0]}, {start[1]}] to [{goal[0]}, {goal[1]}] on a {x_range[1]} by {y_range[1]}  that barriers at {cross_barriers} is penetrable and needs to be avoided, and barriers at {avoid_obstacles} is impenetrable and all barriers need to be avoided."""
                sg.append(query)
        
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=4)
            
    def plot_RRT(self, s_start, s_goal, range_x, range_y, cross_barriers, avoid_barriers, name='RRT', path="temp.png", show=False):
        Env = env_search.Env(range_x[1], range_y[1], cross_barriers, avoid_barriers)  # class Env
        plot = plotting_search.Plotting(s_start, s_goal, Env)
        plot.plot_map(name, path, show)

Dataset().generate_environment_RRT()